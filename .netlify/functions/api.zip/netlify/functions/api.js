// netlify/functions/api.js
var API_KEY = process.env.API_KEY || "";
var API_BASE = process.env.API_BASE_URL || "https://api.deepseek.com";
var AI_MODEL = process.env.AI_MODEL || "deepseek-chat";
function detectChapters(text) {
  const pats = [/第[零一二三四五六七八九十百千万\d]+章\s*[^\n]*/g, /第[零一二三四五六七八九十百千万\d]+节\s*[^\n]*/g, /Chapter\s+\d+/gi, /^第[零一二三四五六七八九十百千万\d]+回\s*[^\n]*/gm];
  for (const p of pats) {
    const m = [...text.matchAll(p)];
    if (m.length >= 3) return m.map((x) => ({ title: x[0].trim(), index: x.index }));
  }
  const pgs = text.split(/\n{2,}/);
  if (pgs.length >= 10) {
    const cs = Math.ceil(pgs.length / Math.ceil(pgs.length / 50));
    const r = [];
    for (let i = 0; i < pgs.length; i += cs) r.push({ title: `\u6BB5\u843D ${Math.floor(i / cs) + 1}`, index: text.indexOf(pgs[i]) });
    return r;
  }
  return [{ title: "\u5168\u6587", index: 0 }];
}
function splitChapters(text, matches) {
  const r = [];
  for (let i = 0; i < matches.length; i++) {
    const s = matches[i].index, e = i < matches.length - 1 ? matches[i + 1].index : text.length;
    r.push({ number: i + 1, title: matches[i].title, content: text.slice(s, e).trim() });
  }
  return r;
}
function buildScriptPrompt(meta) {
  return `\u4F60\u662F\u4E00\u4F4D\u8D44\u6DF1\u7684\u5F71\u89C6\u5267\u672C\u6539\u7F16\u4E13\u5BB6\u3002\u5C06\u5C0F\u8BF4\u6587\u672C\u6539\u7F16\u4E3A YAML \u5267\u672C\u3002\u53EA\u8F93\u51FA YAML\uFF0C\u4E0D\u8981\u4EFB\u4F55\u89E3\u91CA\u3002

\u8F93\u51FA\u683C\u5F0F\uFF1A
\`\`\`yaml
script:
  meta:
    title: "${meta.title || "\u672A\u547D\u540D\u5267\u672C"}"
    format: "${meta.format || "tv_series"}"
  characters:
    - id: "\u4E2D\u6587\u540D"
      name: "\u4E2D\u6587\u540D"
      role: "protagonist"
      description: ""
  scenes:
    - scene_number: 1
      chapter_ref: 1
      location: {name: "", type: "INT", description: ""}
      time: ""; time_of_day: "evening"; summary: ""; mood: ""
      characters_present: [{id: "", status: "present"}]
      beats:
        - {type: "action", description: "", characters: []}
        - {type: "dialogue", character: "", emotion: "", text: "", subtext: ""}
        - {type: "transition", value: "CUT TO"}
      conflict_level: "medium"
\`\`\`

\u89C4\u5219\uFF1A\u89D2\u8272ID\u548Cname\u7EDF\u4E00\u7528\u4E2D\u6587\u540D\u3002\u6BCF\u7AE0\u81F3\u5C112-3\u4E2A\u573A\u666F\u3002YAML \u7F29\u8FDB2\u7A7A\u683C\u3002`;
}
exports.handler = async function(event, context) {
  const path = event.path.replace("/.netlify/functions/api", "").replace("/api", "") || "/";
  const method = event.httpMethod;
  if (path === "/health" || path === "/api/health") {
    return { statusCode: 200, body: JSON.stringify({ status: "ok", model: AI_MODEL, hasKey: !!API_KEY, ts: (/* @__PURE__ */ new Date()).toISOString() }) };
  }
  if (method === "GET") {
    try {
      const fs = require("fs");
      const p = require("path");
      const fp = p.join(__dirname, "../../public", path === "/" ? "index.html" : path);
      if (fs.existsSync(fp)) return { statusCode: 200, headers: { "Content-Type": fp.endsWith(".html") ? "text/html" : "application/octet-stream" }, body: fs.readFileSync(fp, "utf-8") };
    } catch (_) {
    }
    try {
      const fs = require("fs");
      const p = require("path");
      const fp = p.join(__dirname, "../../public/index.html");
      if (fs.existsSync(fp)) return { statusCode: 200, headers: { "Content-Type": "text/html" }, body: fs.readFileSync(fp, "utf-8") };
    } catch (_) {
    }
    return { statusCode: 200, body: "Novel2Script AI" };
  }
  if (!API_KEY) return { statusCode: 500, body: JSON.stringify({ error: "API Key \u672A\u914D\u7F6E" }) };
  let body = {};
  try {
    body = JSON.parse(event.body || "{}");
  } catch (_) {
  }
  if ((path === "/convert" || path === "/api/convert") && method === "POST") {
    const text = body.text || "";
    if (text.trim().length < 500) return { statusCode: 400, body: JSON.stringify({ error: "\u8BF7\u63D0\u4F9B\u81F3\u5C11 500 \u5B57\u7684\u5C0F\u8BF4\u6587\u672C\u3002" }) };
    return new Promise(async (resolve) => {
      const res = { writeHead: () => {
      }, setHeader: () => {
      }, write: () => {
      }, end: () => {
      } };
      let _body = "";
      res.writeHead = (code, headers) => {
        _body += "";
      };
      res.setHeader = () => {
      };
      res.write = (chunk) => {
        _body += chunk;
      };
      res.end = (chunk) => {
        if (chunk) _body += chunk;
        resolve({ statusCode: 200, headers: { "Content-Type": "text/event-stream" }, body: _body });
      };
      const chs = splitChapters(text, detectChapters(text));
      const send = (ev, d) => {
        res.write(`event: ${ev}
data: ${JSON.stringify(d)}

`);
      };
      send("progress", { phase: "detect", message: `\u68C0\u6D4B\u5230 ${chs.length} \u4E2A\u7AE0\u8282`, chapters: chs.map((c) => ({ number: c.number, title: c.title })) });
      const sp = buildScriptPrompt(body.meta || {});
      let um = chs.map((c) => `### ${c.title}
${c.content.slice(0, 1500)}${c.content.length > 1500 ? "\n...(\u5DF2\u622A\u65AD)" : ""}`).join("\n\n");
      um = `\u4EE5\u4E0B\u662F\u4E00\u90E8\u5C0F\u8BF4\u7684 ${chs.length} \u4E2A\u7AE0\u8282\u3002\u8BF7\u5C06\u5176\u6539\u7F16\u4E3A\u5267\u672C YAML\uFF1A

${um}`;
      if (um.length > 18e4) {
        um = chs.map((c) => `### ${c.title}
${c.content.slice(0, 800)}
...(\u7701\u7565)...
${c.content.slice(-800)}`).join("\n\n");
        um = `\u4EE5\u4E0B\u662F\u4E00\u90E8\u5C0F\u8BF4\u7684 ${chs.length} \u4E2A\u7AE0\u8282\u3002\u8BF7\u5C06\u5176\u6539\u7F16\u4E3A\u5267\u672C YAML\uFF1A

${um}`;
      }
      send("progress", { phase: "ai", message: `AI (${AI_MODEL}) \u6B63\u5728\u6539\u7F16...` });
      try {
        const r = await fetch(API_BASE + "/v1/chat/completions", {
          method: "POST",
          headers: { "Content-Type": "application/json", "Authorization": "Bearer " + API_KEY },
          body: JSON.stringify({ model: AI_MODEL, messages: [{ role: "system", content: sp }, { role: "user", content: um }], max_tokens: 6e3, temperature: 0.4, stream: true })
        });
        if (!r.ok) {
          const e = await r.text();
          send("error", { message: "API " + r.status + ": " + e.slice(0, 200) });
          send("done", {});
          res.end();
          return;
        }
        const reader = r.body.getReader();
        const dec = new TextDecoder();
        let buf = "", full = "";
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          buf += dec.decode(value, { stream: true });
          const lines = buf.split("\n");
          buf = lines.pop();
          for (const l of lines) {
            if (!l.startsWith("data: ") || l === "data: [DONE]") continue;
            try {
              const j = JSON.parse(l.slice(6));
              const c = j.choices?.[0]?.delta?.content;
              if (c) {
                full += c;
                send("chunk", { text: c });
              }
            } catch (_) {
            }
          }
        }
        send("progress", { phase: "parse", message: "\u89E3\u6790\u4E2D..." });
        const sceneCount = (full.match(/\n\s*- scene_number:/g) || []).length || (full.match(/\n  - scene_number:/g) || []).length || "\u672A\u77E5";
        const charCount = (full.match(/\n\s*- id:\s*"?([^"\n]+)"?\s*\n\s*name:/g) || []).length || (full.match(/\n  - id:\s*"?([^"\n]+)"?\s*\n\s*name:/g) || []).length || "\u672A\u77E5";
        send("complete", { yaml: full, parsed: true, stats: { chapterCount: chs.length, sceneCount, characterCount: charCount, yamlLength: full.length } });
      } catch (e) {
        send("error", { message: e.message });
      }
      send("done", {});
      res.end();
    });
  }
  if ((path === "/analyze" || path === "/api/analyze") && method === "POST") {
    const text = body.text || "";
    if (text.trim().length < 500) return { statusCode: 400, body: JSON.stringify({ error: "\u8BF7\u63D0\u4F9B\u81F3\u5C11 500 \u5B57\u7684\u5C0F\u8BF4\u6587\u672C\u3002" }) };
    return new Promise(async (resolve) => {
      let _body = "";
      const res = { write: (c) => {
        _body += c;
      }, end: (c) => {
        if (c) _body += c;
        resolve({ statusCode: 200, headers: { "Content-Type": "text/event-stream" }, body: _body });
      }, writeHead: () => {
      }, setHeader: () => {
      } };
      const send = (ev, d) => res.write(`event: ${ev}
data: ${JSON.stringify(d)}

`);
      const chs = splitChapters(text, detectChapters(text));
      const pv = chs.map((c) => `### ${c.title}
${c.content.slice(0, 1500)}`).join("\n\n");
      const sp = `\u4F60\u662F\u5C0F\u8BF4\u5206\u6790\u4E13\u5BB6\u3002\u53EA\u8F93\u51FAJSON\uFF1A{"characters":[{"id":"\u4E2D\u6587\u540D","name":"\u4E2D\u6587\u540D","role":"protagonist|antagonist|supporting|minor","description":"","traits":[],"first_appearance":""}],"locations":[{"name":"","type":"INT|EXT","description":""}],"conflicts":[{"type":"","description":"","involved_characters":[],"intensity":"low|medium|high|climax","chapter_range":""}]}`;
      try {
        send("progress", { phase: "ai", message: "AI \u5206\u6790\u4E2D..." });
        const r = await fetch(API_BASE + "/v1/chat/completions", { method: "POST", headers: { "Content-Type": "application/json", "Authorization": "Bearer " + API_KEY }, body: JSON.stringify({ model: AI_MODEL, messages: [{ role: "system", content: sp }, { role: "user", content: "\u5206\u6790\u4EE5\u4E0B\u5C0F\u8BF4\uFF1A" + pv.slice(0, 8e3) }], max_tokens: 4e3, temperature: 0.3, stream: true }) });
        if (!r.ok) {
          send("error", { message: "API " + r.status });
          send("done", {});
          res.end();
          return;
        }
        const reader = r.body.getReader();
        const dec = new TextDecoder();
        let buf = "", full = "";
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          buf += dec.decode(value, { stream: true });
          const lines = buf.split("\n");
          buf = lines.pop();
          for (const l of lines) {
            if (!l.startsWith("data: ") || l === "data: [DONE]") continue;
            try {
              const j = JSON.parse(l.slice(6));
              const c = j.choices?.[0]?.delta?.content;
              if (c) {
                full += c;
                send("chunk", { text: c });
              }
            } catch (_) {
            }
          }
        }
        let analysis = null;
        try {
          const m = full.match(/\{[\s\S]*\}/);
          if (m) analysis = JSON.parse(m[0]);
        } catch (_) {
        }
        send("complete", { analysis, parsed: !!analysis, stats: { chapters: chs.length, characters: analysis?.characters?.length || 0, locations: analysis?.locations?.length || 0, conflicts: analysis?.conflicts?.length || 0 } });
      } catch (e) {
        send("error", { message: e.message });
      }
      send("done", {});
      res.end();
    });
  }
  if ((path === "/optimize-dialogues" || path === "/api/optimize-dialogues") && method === "POST") {
    const yt = body.yaml || "";
    if (yt.trim().length < 100) return { statusCode: 400, body: JSON.stringify({ error: "\u8BF7\u63D0\u4F9B YAML \u5185\u5BB9" }) };
    const dials = [];
    const sceneBlocks = yt.split(/\n\s*- scene_number:/);
    let sn = 0;
    for (const block of sceneBlocks) {
      sn++;
      const dm = block.matchAll(/\n\s*character:\s*"?([^"\n]+)"?[\s\S]*?\n\s*text:\s*"([^"]+)"/g);
      for (const m of dm) {
        dials.push({ scene_number: sn, character: m[1].trim(), original_text: m[2] });
      }
    }
    if (dials.length === 0) return { statusCode: 400, body: JSON.stringify({ error: "\u672A\u627E\u5230\u5BF9\u8BDD" }) };
    return new Promise(async (resolve) => {
      let _body = "";
      const res = { write: (c) => {
        _body += c;
      }, end: (c) => {
        if (c) _body += c;
        resolve({ statusCode: 200, headers: { "Content-Type": "text/event-stream" }, body: _body });
      }, writeHead: () => {
      }, setHeader: () => {
      } };
      const send = (ev, d) => res.write(`event: ${ev}
data: ${JSON.stringify(d)}

`);
      send("progress", { phase: "extract", message: `\u63D0\u53D6\u5230 ${dials.length} \u53E5\u5BF9\u8BDD` });
      const dl = dials.map((d, i) => `[${i}] ${d.character}: "${d.original_text}"`).join("\n");
      try {
        const sp = '\u4F60\u662F\u5F71\u89C6\u5BF9\u767D\u7F16\u8F91\u3002\u4F18\u5316\u5BF9\u8BDD\u3002\u8F93\u51FAJSON\uFF1A{"dialogues":[{"index":0,"character":"\u89D2\u8272\u540D","original":"\u539F\u5BF9\u767D","optimized":"\u4F18\u5316\u540E","improvement":"\u8BF4\u660E"}]}\u3002\u89D2\u8272\u540D\u5FC5\u987B\u7528\u4E2D\u6587\u3002';
        const r = await fetch(API_BASE + "/v1/chat/completions", { method: "POST", headers: { "Content-Type": "application/json", "Authorization": "Bearer " + API_KEY }, body: JSON.stringify({ model: AI_MODEL, messages: [{ role: "system", content: sp }, { role: "user", content: "\u4F18\u5316\uFF1A" + dl.slice(0, 6e3) }], max_tokens: 4e3, temperature: 0.5, stream: true }) });
        if (!r.ok) {
          send("error", { message: "API " + r.status });
          send("done", {});
          res.end();
          return;
        }
        const reader = r.body.getReader();
        const dec = new TextDecoder();
        let buf = "", full = "";
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          buf += dec.decode(value, { stream: true });
          const lines = buf.split("\n");
          buf = lines.pop();
          for (const l of lines) {
            if (!l.startsWith("data: ") || l === "data: [DONE]") continue;
            try {
              const j = JSON.parse(l.slice(6));
              const c = j.choices?.[0]?.delta?.content;
              if (c) {
                full += c;
                send("chunk", { text: c });
              }
            } catch (_) {
            }
          }
        }
        let result = null;
        try {
          const m = full.match(/\{[\s\S]*\}/);
          if (m) result = JSON.parse(m[0]);
        } catch (_) {
        }
        send("complete", { dialogues: result?.dialogues || [], summary: result?.summary || "", total_count: dials.length, optimized_count: result?.dialogues?.length || 0 });
      } catch (e) {
        send("error", { message: e.message });
      }
      send("done", {});
      res.end();
    });
  }
  if ((path === "/analyze-emotions" || path === "/api/analyze-emotions") && method === "POST") {
    const yt = body.yaml || "";
    if (yt.trim().length < 100) return { statusCode: 400, body: JSON.stringify({ error: "\u8BF7\u63D0\u4F9B YAML \u5185\u5BB9" }) };
    const scenes = [];
    const sceneBlocks = yt.split(/\n\s*- scene_number:/);
    let sn2 = 0;
    for (const block of sceneBlocks) {
      sn2++;
      const locM = block.match(/location:\s*\n\s*name:\s*"?([^"\n]+)"?/);
      const moodM = block.match(/mood:\s*"?([^"\n]+)"?/);
      const emos = [];
      const dm2 = block.matchAll(/\n\s*character:\s*"?([^"\n]+)"?[\s\S]*?\n\s*emotion:\s*"?([^"\n]+)"?/g);
      for (const m of dm2) {
        emos.push(m[1].trim() + ":" + m[2].trim());
      }
      scenes.push(`\u573A\u666F${sn2}[${locM?.[1] || "?"}] \u6C1B\u56F4:${moodM?.[1] || ""} | ${emos.join(", ")}`);
    }
    return new Promise(async (resolve) => {
      let _body = "";
      const res = { write: (c) => {
        _body += c;
      }, end: (c) => {
        if (c) _body += c;
        resolve({ statusCode: 200, headers: { "Content-Type": "text/event-stream" }, body: _body });
      }, writeHead: () => {
      }, setHeader: () => {
      } };
      const send = (ev, d) => res.write(`event: ${ev}
data: ${JSON.stringify(d)}

`);
      send("progress", { phase: "analyze", message: `\u5206\u6790 ${scenes.length} \u4E2A\u573A\u666F` });
      try {
        const sp = '\u4F60\u662F\u8868\u6F14\u6307\u5BFC\u3002\u5206\u6790\u60C5\u7EEA\u3002\u8F93\u51FAJSON\uFF1A{"emotions":{"\u89D2\u8272\u540D":{"scene_1":"\u60C5\u7EEA"}},"emotion_arcs":{"\u89D2\u8272\u540D":{"arc_description":"","key_moments":[]}},"performance_notes":{"\u89D2\u8272\u540D":""},"overall_tone":""}\u3002\u89D2\u8272\u540D\u5FC5\u987B\u7528\u4E2D\u6587\u3002';
        const r = await fetch(API_BASE + "/v1/chat/completions", { method: "POST", headers: { "Content-Type": "application/json", "Authorization": "Bearer " + API_KEY }, body: JSON.stringify({ model: AI_MODEL, messages: [{ role: "system", content: sp }, { role: "user", content: "\u5206\u6790\u60C5\u7EEA\uFF1A" + scenes.join("\n").slice(0, 5e3) }], max_tokens: 4e3, temperature: 0.4, stream: true }) });
        if (!r.ok) {
          send("error", { message: "API " + r.status });
          send("done", {});
          res.end();
          return;
        }
        const reader = r.body.getReader();
        const dec = new TextDecoder();
        let buf = "", full = "";
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          buf += dec.decode(value, { stream: true });
          const lines = buf.split("\n");
          buf = lines.pop();
          for (const l of lines) {
            if (!l.startsWith("data: ") || l === "data: [DONE]") continue;
            try {
              const j = JSON.parse(l.slice(6));
              const c = j.choices?.[0]?.delta?.content;
              if (c) {
                full += c;
                send("chunk", { text: c });
              }
            } catch (_) {
            }
          }
        }
        let result = null;
        try {
          const m = full.match(/\{[\s\S]*\}/);
          if (m) result = JSON.parse(m[0]);
        } catch (_) {
        }
        send("complete", { emotions: result?.emotions || {}, emotion_arcs: result?.emotion_arcs || {}, performance_notes: result?.performance_notes || {}, overall_tone: result?.overall_tone || "" });
      } catch (e) {
        send("error", { message: e.message });
      }
      send("done", {});
      res.end();
    });
  }
  return { statusCode: 404, body: JSON.stringify({ error: "Not found" }) };
};
